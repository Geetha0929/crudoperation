package com.mvc.pack.controller;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mvc.pack.dao.EmployeeDAO;
 
import com.mvc.pack.form.Employee;

 @Controller
public class EmpController {
	@Autowired    
    EmployeeDAO employeeDao;
	

@RequestMapping("/empForm")  
public String add(Model m)  
{  
    m.addAttribute("emp", new  Employee());  
    return "empForm";  
}

@RequestMapping(value = "/addEmployee",	method = RequestMethod.POST)
 	 	public ModelAndView addStudent(Employee employee) {
	employeeDao.insert(employee);
	ModelAndView model1=new ModelAndView("final");
      
      return model1;
   }

	



@RequestMapping("/editForm")
public ModelAndView editEmp()
{
	 
	return new ModelAndView("editForm");
	 
}


@RequestMapping("/editEmp")  
public String edit( @RequestParam("eid") int id, Model m){    
    Employee emp=employeeDao.getEmpById(id);    
    m.addAttribute("editEmpForm",emp);  
    return "editAction";    
}  

@RequestMapping("/editEmployee")
public String modify(Employee employee)
{
	employeeDao.modify(employee);
	return "final";
	 
}
@RequestMapping("/deleteForm")
public ModelAndView deleteEmp()
{
	return new ModelAndView("deleteForm");
}
@RequestMapping("/deleteEmp")
public String del( @RequestParam("eid") int id, Model m){   
	Employee emp=employeeDao.getEmpById(id);
	m.addAttribute("delEmpForm", emp);
		return "deleteAction";
}
@RequestMapping("/deleteEmployee")
public String delete(Employee employee){
	employeeDao.delete( employee);
	return "final";
}
@RequestMapping("/viewForm")
public ModelAndView viewEmp()
{
     
    return new ModelAndView("viewForm");
     
}

  @RequestMapping("/viewEmp") 
  public String view( @RequestParam("eid") int id, Model m){ 
      Employee emp=employeeDao.getEmpById(id);
      int eid=emp.getId();
      m.addAttribute("eid",eid);
      String name=emp.getName();
      m.addAttribute("name",name);
      float salary=emp.getSalary();
      m.addAttribute("salary",salary);
   return "viewFinal"; }
 }