package com.mvc.pack.dao;
import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;

 
import com.mvc.pack.form.Employee;
public class EmployeeDAO {

	@Autowired
private DataSource dataSource;
 
	
	 
	 
	public void insert(Employee e) {
		
		 
	   	 	
		JdbcTemplate insert = new JdbcTemplate(dataSource);
	insert.update("INSERT INTO employee (id, name,salary)" +
	    		" VALUES(?,?,?)",
	    		e.getId(),e.getName(),e.getSalary());
		
		 
	} 
	
	public Employee getEmpById(int id){    
		JdbcTemplate obj = new JdbcTemplate(dataSource);
	    String sql="select * from employee where id=?";    
	  
	    Employee emp= obj.queryForObject(sql, new Object[]{id},new BeanPropertyRowMapper<Employee>(Employee.class));  
	    return emp;
	    
		 
	    
	}    
	
	
	public void modify(Employee e) {
		
		 
   	 	
		JdbcTemplate insert = new JdbcTemplate(dataSource);
		insert.update("update employee set name='"+e.getName()+"',salary="+e.getSalary()+"where id="+e.getId());
		
		 
	} 
	
	public void delete(Employee e) {
		JdbcTemplate delete = new JdbcTemplate(dataSource);
    delete.update("delete from employee where id="+e.getId());
	}
	public void view(Employee e) {
        JdbcTemplate view = new JdbcTemplate(dataSource);
        String sql="select * from employee where id="+e.getId();   
          view.execute(sql);
     
       
    }
}


